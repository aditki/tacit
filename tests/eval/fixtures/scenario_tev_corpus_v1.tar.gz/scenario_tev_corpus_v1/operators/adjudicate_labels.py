"""Independent frozen-rubric adjudication, no network or Tev inference."""
from pathlib import Path
from datetime import datetime, UTC
import hashlib
import json
import os
import sys

sys.path.insert(0, '/private/tmp/tacit-offline-implementation')
from tests.eval import evidence_decisions as d

ROOT = Path(__file__).resolve().parent

def read(name):
    return json.loads((ROOT / name).read_bytes())

def digest(name):
    return hashlib.sha256((ROOT / name).read_bytes()).hexdigest()

master = read('source_manifest.json')
plan = read('source_plan.json')
freeze = read('source_freeze.json')
rules = read('label_rules.json')
assert freeze['source_manifest_sha256'] == digest('source_manifest.json')
assert freeze['source_plan_sha256'] == digest('source_plan.json')
assert freeze['label_rules_sha256'] == digest('label_rules.json')
assert master['timing_profile'] == freeze['timing_profile'] == 'per-case-admission-clock/1'
assert len(master['cases']) == 13
assert master['baseline_code_sha'] == '1af49fd1ef552446ff9856164e0d9811f5d76e85'
source_cases = {item['case_id']: item for item in plan['cases']}
expected_resources = {
    'gamma_cpu': [('cpu_usage', 'container_cpu_usage_seconds_total')],
    'gamma_memory': [('memory_usage', 'container_memory_working_set_bytes')],
    'gamma_network': [('network_bytes', 'container_network_receive_bytes_total', 'container_network_transmit_bytes_total')],
    'gamma_cpu_memory': [('cpu_usage', 'container_cpu_usage_seconds_total'), ('memory_usage', 'container_memory_working_set_bytes')],
}
cases = []
for item in master['cases']:
    case_id = item['case_id']
    directory = ROOT / 'captures' / case_id
    index = json.loads((directory / 'capture_index.json').read_bytes())
    assert index['measurement_completed'] and index['runtime_terminal']['terminal_zero']
    assert index['runtime_terminal']['root_state'] == 'closed'
    assert all(index['runtime_terminal'][field] == 0 for field in (
        'root_owner_count', 'provider_manager_count', 'in_flight', 'retained', 'blocking_in_flight', 'service_owner_in_flight'))
    assert index['timing_profile'] == 'per-case-admission-clock/1'
    assert 0 <= index['replay_freshness_ms'] <= 60_000
    assert index['baseline_code_sha'] == master['baseline_code_sha']
    admission = json.loads((directory / 'baseline_admission.json').read_bytes())
    imported = json.loads((directory / 'import.json').read_bytes())
    assert imported['instant_series_count'] > 0 and imported['samples_last_five_minutes'] > 0
    assert index['master_sha256'] == freeze['source_manifest_sha256']
    record = {
        'case_id': case_id,
        'capture_available': index['capture_available'],
        'pipeline_status': index['pipeline_status'],
        'baseline_started_at': index['baseline_started_at'],
        'finished_at': index['finished_at'],
        'replay_freshness_ms': index['replay_freshness_ms'],
        'capture_index_sha256': hashlib.sha256((directory / 'capture_index.json').read_bytes()).hexdigest(),
        'timing_validated': True,
    }
    if not index['capture_available']:
        assert not (directory / 'assessment.tar.gz').exists() and not (directory / 'snapshot.json').exists()
        record.update(
            label_status='failed_capture_no_candidate_labels', labels=None,
            rationale='The actual baseline failed before producing an assessment capture. Retain failed coverage; no candidate identity or baseline is manufactured.',
            projection_status='failed_capture', admissible_menu=[], candidate_ids=[],
            source_coverage={'capture_failed': True, 'fresh_source_verified': True,
                             'numeric_measurements_model_visible': False, 'priority_discriminator_model_visible': False},
        )
        cases.append(record)
        continue
    snapshot = json.loads((directory / 'snapshot.json').read_bytes())
    projection = d.captured_projection(snapshot)
    state = projection['state']
    observations = list(state['observations'].values())
    supported = [o for o in observations if o['valid_query'] and o['non_empty'] and o['survived'] and o['outcome'] == 'SUPPORTED_OBSERVATION']
    metrics = sorted({o['resolution_metric'] for o in supported})
    if item['dataset'] == 'clickstack':
        expected = [('visa_validation_cache_size_entries',)]
    else:
        expected = expected_resources[item['family_id']]
    coverage = {
        'capture_failed': False, 'fresh_source_verified': True,
        'observed_metrics': metrics, 'supported_observation_count': len(supported),
        'predeclared_source_target_groups': [list(group) for group in expected],
        'source_target_group_availability': [bool(set(group) & set(metrics)) for group in expected],
        'numeric_measurements_model_visible': False,
        'priority_discriminator_model_visible': False,
        'baseline_ranking_used_as_label_truth': False,
        'hidden_injection_used_as_label_truth': False,
    }
    # Baseline 1af49fd records typed query availability, not sample values. The
    # observed runtime-reason strings in this cohort are generated as
    # 'Observed ... via ... in ...', never a recorded condition comparison.
    assert all(set(o) == {'requirement_id', 'resolution_metric', 'panel_title', 'query', 'datasource_uid', 'valid_query', 'non_empty', 'survived', 'outcome', 'rejection_reason'} for o in observations)
    for candidate in state['candidates'].values():
        assert all(reason.startswith('Observed ') and ' via ' in reason for reason in candidate['runtime_evidence'])
    kind = item['class']
    if kind == 'controlled_application_cache_incident':
        rationale = 'Frozen ClickStack labels require actual Visa-cache target support or a priority-discriminating fact. The capture exposes generic Redis query availability but no Visa cache measurement/observation or comparative condition, so the packet cannot justify a preferred next suspect.'
    elif kind == 'injected_resource_window':
        rationale = 'The capture shows CPU/memory query availability but no measured condition or comparative priority fact. Frozen source rules prohibit deriving a priority from injected-fault metadata that the model cannot observe. Availability alone is insufficient under this rubric.'
    elif kind == 'pre_interference_healthy':
        rationale = 'The predeclared healthy-control rule requires no next-suspect priority. Valid resource queries do not establish abnormal behavior; this packet contains no measured abnormal condition.'
    else:
        rationale = 'The predeclared symptom-only/resource-evidence-absent rule requires insufficient priority evidence. Showing request symptoms cannot justify an unseen resource cause or a preferred culprit.'
    record.update(
        label_status='adjudicated_from_frozen_rules_and_visible_facts',
        labels={'acceptable': [], 'contradicted': [], 'required_abstention': True},
        rationale=rationale, projection_status=projection['status'],
        candidate_ids=sorted(projection['candidate_ids']), admissible_menu=projection['menu'],
        projected_state_sha256=d.sha(d.canonical(state)), source_coverage=coverage,
    )
    cases.append(record)

result = {
    'schema_version': 'scenario-label-adjudication/1', 'status': 'draft_ready_for_parent_review',
    'adjudicated_at': datetime.now(UTC).isoformat(),
    'method': 'Independent agent review against the already frozen rubric and model-visible captured facts. No baseline rank/score/confidence/order, expected_outcomes, hidden injected labels or Tev outputs supply priority truth. Not independent human adjudication.',
    'source_manifest_sha256': digest('source_manifest.json'), 'source_freeze_sha256': digest('source_freeze.json'),
    'source_plan_sha256': digest('source_plan.json'), 'label_rules_sha256': digest('label_rules.json'),
    'cases': cases,
    'counts': {
        'cases': len(cases), 'captured': sum(item['capture_available'] for item in cases),
        'failed_capture': sum(not item['capture_available'] for item in cases),
        'model_eligible': sum(item['projection_status'] == 'eligible' for item in cases),
        'deterministic_no_call': sum(item['projection_status'] == 'deterministic' for item in cases),
        'policy_no_call': sum(item['projection_status'] == 'policy_abstention' for item in cases),
        'required_abstention_labels': sum(bool(item['labels'] and item['labels']['required_abstention']) for item in cases),
    },
    'current_corpus_tev_outputs_seen': False, 'external_inference_calls_by_adjudicator': 0,
}
equivalent = {}
for record in cases:
    if record.get('projected_state_sha256'):
        equivalent.setdefault(record['projected_state_sha256'], []).append(record['case_id'])
result['identical_projected_state_groups'] = [
    {'state_sha256': digest_value, 'case_ids': case_ids}
    for digest_value, case_ids in sorted(equivalent.items()) if len(case_ids) > 1
]
path = ROOT / 'label_adjudication.json'
fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'wb') as stream:
    stream.write(d.canonical(result))
print(json.dumps({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'counts': result['counts']}))
