"""Replay recorded contracts with their exact acquisition implementation."""
import hashlib
import json
import socket
import sqlite3
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
from tacit.investigation_contract import InvestigationContract
from tacit.investigation_replay import InvestigationReplaySnapshot, rebuild_contract

ROOT = Path(__file__).resolve().parent


def denied(*args, **kwargs):
    raise AssertionError('Frozen replay tried an external capability')


socket.socket = denied
sqlite3.connect = denied
subprocess.Popen = denied
rows = []
for directory in sorted((ROOT / 'captures').iterdir()):
    index = json.loads((directory / 'capture_index.json').read_bytes())
    assert index['baseline_code_sha'] == '1af49fd1ef552446ff9856164e0d9811f5d76e85'
    if not index['capture_available']:
        assert not (directory / 'assessment.tar.gz').exists()
        continue
    contract = InvestigationContract.model_validate_json((directory / 'contract.json').read_bytes())
    snapshot = InvestigationReplaySnapshot.model_validate_json((directory / 'snapshot.json').read_bytes())
    rebuilt = rebuild_contract(snapshot)
    assert rebuilt.runtime.input_fingerprint == contract.runtime.input_fingerprint == index['input_fingerprint']
    assert rebuilt.runtime.output_fingerprint == contract.runtime.output_fingerprint == index['output_fingerprint']
    assert rebuilt.decision_log == contract.decision_log
    assert rebuilt.provenance == contract.provenance
    rows.append({'case_id': index['case_id'], 'bundle_sha256': index['bundle_sha256'],
                 'snapshot_sha256': hashlib.sha256((directory / 'snapshot.json').read_bytes()).hexdigest(),
                 'input_fingerprint': rebuilt.runtime.input_fingerprint,
                 'output_fingerprint': rebuilt.runtime.output_fingerprint,
                 'decisions_and_provenance_equal': True})
assert len(rows) == 9
audit = {'schema_version': 'acquisition-frozen-replay/1',
         'baseline_code_sha': '1af49fd1ef552446ff9856164e0d9811f5d76e85',
         'network_database_subprocess_denied': True, 'cases': rows}
with (ROOT / 'acquisition_replay_audit.json').open('xb') as output:
    output.write((json.dumps(audit, sort_keys=True, separators=(',', ':')) + '\n').encode())
print(json.dumps({'replayed': len(rows), 'external_capabilities': 'denied'}))
