"""Run the entire clock-corrected cohort; freeze each timestamp-only admission."""
import gzip
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STACK = Path('/private/tmp/tacit-scenario-corpus-20261118/stack')
PYTHON = '/Users/adityamudunuri/src/tacit/.venv/bin/python'
CODE = '/private/tmp/tacit-acquisition-implementation'
RUN_ID = 'tev-corpus-8f0abc2b5ae54e469101f1acab0b9b60'
sys.path.insert(0, CODE)
from demo.rebase_otlp_metrics import shift_timestamps


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False) + '\n').encode()


def sha(body):
    return hashlib.sha256(body).hexdigest()


def write(path, body):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(body)


master_body = (ROOT / 'source_manifest.json').read_bytes()
master = json.loads(master_body)
assert master['timing_profile'] == 'per-case-admission-clock/1'
deadline = time.monotonic() + 45 * 60
previous = None
for case in master['cases']:
    assert time.monotonic() < deadline
    if previous:
        result = json.loads((ROOT / 'captures' / previous['case_id'] / 'capture_index.json').read_bytes())
        terminal = result['runtime_terminal']
        assert result['measurement_completed'] and terminal['terminal_zero'] and terminal['root_state'] == 'closed'
    else:
        prior_root = STACK.parent
        previous_cases = list((prior_root / 'captures').glob('*/capture_index.json'))
        assert len(previous_cases) == 13
        assert all(json.loads(path.read_bytes())['runtime_terminal']['terminal_zero'] for path in previous_cases)
    with (ROOT / ('reset-before-' + case['case_id'] + '.log')).open('xb') as log:
        reset = subprocess.run([PYTHON, str(STACK / 'reset_owned_stack.py'), 'reset', '--run-id', RUN_ID],
                               cwd=CODE, stdout=log, stderr=subprocess.STDOUT)
    assert reset.returncode == 0, 'owned reset failed or uncertain; no automatic retry'
    owner = json.loads((STACK / 'ownership.json').read_bytes())
    owner.update(vm_url=owner['endpoints']['victoriametrics'], grafana_url=owner['endpoints']['grafana'],
                 otel_url=owner['endpoints']['otel_metrics'].removesuffix('/v1/metrics'),
                 datasource_url=owner['datasource']['url'])
    ownership_body = canonical(owner)
    base_body = (ROOT / case['metric_path']).read_bytes()
    assert sha(base_body) == case['metric_sha256']
    base = gzip.decompress(base_body)
    end_ms = time.time_ns() // 1_000_000 - 5000
    offset_ms = end_ms - master['frozen_end_ms']
    if case['format'] == 'prometheus':
        admitted = b''.join(prefix + b' ' + str(int(stamp) + offset_ms).encode() + b'\n'
                            for line in base.splitlines() if line.strip()
                            for prefix, stamp in [line.rsplit(b' ', 1)])
    else:
        admitted = b''.join(canonical(shift_timestamps(json.loads(line), offset_ms * 1_000_000))
                            for line in base.splitlines() if line.strip())
    compressed = gzip.compress(admitted, mtime=0)
    path = 'admitted_replays/' + Path(case['metric_path']).name
    write(ROOT / path, compressed)
    record = {'schema_version': 'scenario-replay-admission/1', 'timing_profile': master['timing_profile'],
              'case_id': case['case_id'], 'metric_path': path, 'metric_sha256': sha(compressed),
              'expanded_sha256': sha(admitted), 'expanded_bytes': len(admitted),
              'offset_ms': offset_ms, 'end_ms': end_ms, 'source_end_ms': master['frozen_end_ms'],
              'frozen_at': datetime.now(UTC).isoformat(), 'base_metric_path': case['metric_path'],
              'base_metric_sha256': case['metric_sha256']}
    write(ROOT / 'admitted_replays' / (case['case_id'] + '.admission.json'), canonical(record))
    admitted_case = {**case, 'admitted_replay': {**record, 'admission_freeze_sha256': sha(canonical(record))}}
    output = ROOT / 'execution' / case['case_id']
    output.mkdir(mode=0o700, parents=True)
    execution = {**master, 'cases': [admitted_case], 'project': owner['project'], 'run_id': RUN_ID,
                 'ownership_sha256': sha(ownership_body), 'master_manifest_path': str(ROOT / 'source_manifest.json'),
                 'master_sha256': sha(master_body), 'endpoints': {'grafana_url': owner['grafana_url'],
                 'vm_url': owner['vm_url'], 'otel_url': owner['otel_url'], 'llm_api_base': 'http://127.0.0.1:11434'}}
    write(output / 'ownership.json', ownership_body)
    write(output / 'manifest.json', canonical(execution))
    with (ROOT / ('baseline-' + case['case_id'] + '.log')).open('xb') as log:
        result = subprocess.run([PYTHON, str(ROOT / 'capture_baselines.py'), '--manifest', str(output / 'manifest.json')],
                                cwd=CODE, stdout=log, stderr=subprocess.STDOUT)
    assert result.returncode == 0, 'capture/cleanup failed; no automatic retry'
    index = json.loads((ROOT / 'captures' / case['case_id'] / 'capture_index.json').read_bytes())
    assert index['measurement_completed'] and index['runtime_terminal']['terminal_zero']
    print(json.dumps({key: index[key] for key in ('case_id', 'capture_available', 'pipeline_status', 'elapsed_ms')}), flush=True)
    previous = case
print(json.dumps({'completed': len(master['cases']), 'profile': master['timing_profile'], 'automatic_retries': 0}), flush=True)
