"""External pure regression gate; never starts a runtime or contacts a service."""

import importlib.util
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "capture_v2", Path(__file__).with_name("capture_baselines.py")
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class AdmissionClockTests(unittest.TestCase):
    def test_constant_shift_preserves_values_and_is_fresh(self):
        result = module.verify_time_only_transform(
            b'metric{service="api"} 7 1000\n',
            b'metric{service="api"} 7 100000\n',
            "prometheus",
            99000,
            100000,
            100050,
        )
        self.assertEqual(result["replay_freshness_ms"], 50)

    def test_old_global_end_is_rejected(self):
        with self.assertRaises(AssertionError):
            module.verify_time_only_transform(
                b"metric 7 1000\n",
                b"metric 7 1000\n",
                "prometheus",
                0,
                1000,
                400000,
            )

    def test_freshness_cannot_hide_changed_value(self):
        with self.assertRaises(AssertionError):
            module.verify_time_only_transform(
                b"metric 7 1000\n",
                b"metric 9 100000\n",
                "prometheus",
                99000,
                100000,
                100050,
            )

    def test_otlp_timestamp_only_and_non_time_type_preserved(self):
        base = b'{"timeUnixNano":"1000000000","doubleValue":7,"flag":true}\n'
        good = b'{"timeUnixNano":"100000000000","doubleValue":7,"flag":true}\n'
        result = module.verify_time_only_transform(
            base, good, "otlp_jsonl", 99000, 100000, 100050
        )
        self.assertEqual(result["sample_count"], 1)
        bad = good.replace(b'"flag":true', b'"flag":1')
        with self.assertRaises(AssertionError):
            module.verify_time_only_transform(
                base, bad, "otlp_jsonl", 99000, 100000, 100050
            )


if __name__ == "__main__":
    unittest.main()
