"""Freeze accepted independent labels and portable capture references; no inference."""
from pathlib import Path
from datetime import UTC, datetime
import copy
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parent

def read(path):
    return json.loads((ROOT / path).read_bytes())

def sha(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()

def save(path, value):
    fd = os.open(ROOT / path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(canonical(value))

def portable(value):
    if isinstance(value, dict):
        return {k: portable(v) for k, v in value.items()}
    if isinstance(value, list):
        return [portable(v) for v in value]
    if isinstance(value, str) and value.startswith(str(ROOT) + '/'):
        return str(Path(value).relative_to(ROOT))
    return value

master = read('source_manifest.json')
freeze = read('source_freeze.json')
rules = read('label_rules.json')
adjudication = read('label_adjudication.json')
assert freeze['source_manifest_sha256'] == sha('source_manifest.json')
assert freeze['source_plan_sha256'] == sha('source_plan.json')
assert freeze['label_rules_sha256'] == sha('label_rules.json')
assert adjudication['source_manifest_sha256'] == sha('source_manifest.json')
assert adjudication['source_freeze_sha256'] == sha('source_freeze.json')
assert adjudication['label_rules_sha256'] == sha('label_rules.json')
assert len(master['cases']) == len(adjudication['cases']) == 13
by_id = {r['case_id']: r for r in adjudication['cases']}
records = []
for source in master['cases']:
    cid = source['case_id']
    prefix = f'captures/{cid}/'
    original = read(prefix + 'capture_index.json')
    reviewed = by_id[cid]
    assert reviewed['capture_index_sha256'] == sha(prefix + 'capture_index.json')
    assert reviewed['capture_available'] == original['capture_available']
    assert original['master_sha256'] == sha('source_manifest.json')
    assert original['baseline_code_sha'] == master['baseline_code_sha']
    assert original['measurement_completed'] is True
    terminal = original['runtime_terminal']
    assert terminal['terminal_zero'] is True and terminal['root_state'] == 'closed'
    assert all(terminal[k] == 0 for k in ('root_owner_count','provider_manager_count','in_flight','retained','blocking_in_flight','service_owner_in_flight'))
    assert original['ownership_sha256'] == sha(prefix + 'ownership.json')
    admission = read(prefix + 'admission_freeze.json')
    assert original['admitted_replay']['admission_freeze_sha256'] == sha(prefix + 'admission_freeze.json')
    assert {k:v for k,v in original['admitted_replay'].items() if k != 'admission_freeze_sha256'} == admission
    assert 0 <= original['replay_freshness_ms'] <= 60_000
    assert original['baseline_started_ms'] - admission['end_ms'] == original['replay_freshness_ms']
    assert original['baseline_started_at'] == read(prefix + 'baseline_admission.json')['baseline_started_at']
    imported = read(prefix + 'import.json')
    assert imported['instant_series_count'] > 0 and imported['samples_last_five_minutes'] > 0
    assert sha(source['metric_path']) == source['metric_sha256'] == admission['base_metric_sha256']
    assert sha(admission['metric_path']) == admission['metric_sha256']
    execution = read(prefix + 'execution_manifest.json')
    assert execution['master_sha256'] == sha('source_manifest.json')
    assert execution['baseline_code_sha'] == master['baseline_code_sha']
    assert execution['model'] == master['model'] and execution['prompt'] == master['prompt']
    assert execution['ownership_sha256'] == original['ownership_sha256']
    runs = read(prefix + 'runs.json')
    events = read(prefix + 'events.json')
    response = read(prefix + 'response.json')
    assert all(r['investigation_id'] == original['investigation_id'] for r in runs)
    assert all(e['investigation_id'] == original['investigation_id'] for e in events)
    audit = {
        'schema_version':'scenario-run-audit/1', 'case_id':cid,
        'investigation_id':original['investigation_id'],
        'pipeline_status':original['pipeline_status'],
        'capture_available':original['capture_available'],
        'measurement_completed':original['measurement_completed'],
        'baseline_started_at':original['baseline_started_at'], 'finished_at':original['finished_at'],
        'timing_profile':original['timing_profile'], 'replay_freshness_ms':original['replay_freshness_ms'],
        'runtime_terminal':copy.deepcopy(terminal),
        'runs_path':prefix+'runs.json', 'runs_sha256':sha(prefix+'runs.json'),
        'run_count':len(runs), 'runs':copy.deepcopy(runs),
        'events_path':prefix+'events.json', 'events_sha256':sha(prefix+'events.json'),
        'event_count':len(events),
        'response_path':prefix+'response.json', 'response_sha256':sha(prefix+'response.json'),
        'execution_manifest_path':prefix+'execution_manifest.json', 'execution_manifest_sha256':sha(prefix+'execution_manifest.json'),
        'original_capture_index_path':prefix+'capture_index.json', 'original_capture_index_sha256':sha(prefix+'capture_index.json'),
    }
    if original['capture_available']:
        assert reviewed['labels'] == {'acceptable': [],'contradicted': [],'required_abstention': True}
        assert original['pipeline_status'] == 'completed'
        assert sha(prefix+'assessment.tar.gz') == original['bundle_sha256']
        audit.update(bundle_sha256=original['bundle_sha256'], input_fingerprint=original['input_fingerprint'], output_fingerprint=original['output_fingerprint'], replay_output_fingerprint=original['replay_output_fingerprint'])
        assert original['replay_output_fingerprint'] == original['output_fingerprint']
    else:
        assert reviewed['labels'] is None
        assert not (ROOT / prefix / 'assessment.tar.gz').exists()
        assert not (ROOT / prefix / 'snapshot.json').exists()
    save(prefix+'run_audit.json', portable(audit))
    record = portable(copy.deepcopy(original))
    record.update(original_capture_index_path=prefix+'capture_index.json', original_capture_index_sha256=sha(prefix+'capture_index.json'),
        run_audit_path=prefix+'run_audit.json', run_audit_sha256=sha(prefix+'run_audit.json'),
        execution_manifest_path=prefix+'execution_manifest.json', execution_manifest_sha256=sha(prefix+'execution_manifest.json'),
        admission_freeze_path=prefix+'admission_freeze.json', import_path=prefix+'import.json', import_sha256=sha(prefix+'import.json'))
    if original['capture_available']:
        record.update(snapshot_path=prefix+'snapshot.json', snapshot_sha256=sha(prefix+'snapshot.json'), contract_path=prefix+'contract.json', contract_sha256=sha(prefix+'contract.json'))
    records.append(record)

now = datetime.now(UTC).isoformat()
index = {
    'schema_version':'scenario-capture-index/1', 'consolidated_at':now,
    'source_manifest_sha256':sha('source_manifest.json'), 'master_sha256':sha('source_manifest.json'),
    'source_freeze_sha256':sha('source_freeze.json'), 'baseline_code_sha':master['baseline_code_sha'],
    'timing_profile':master['timing_profile'], 'cases':records, 'counts':copy.deepcopy(adjudication['counts']),
    'path_rule':'Artifact paths are relative to corpus root; original per-case indexes are unchanged.',
    'status_rule':'measurement_completed denotes a finished measurement attempt, not an inferred successful assessment.',
}
save('capture_index.json', index)
labels = {
    'schema_version':'scenario-labels/1', 'frozen_at':datetime.now(UTC).isoformat(),
    'status':'frozen', 'approval':'Parent accepted the independent adjudication: nine insufficient labels; four failed captures have labels=None.',
    'source_freeze_sha256':sha('source_freeze.json'), 'source_manifest_sha256':sha('source_manifest.json'),
    'master_sha256':sha('source_manifest.json'), 'source_plan_sha256':sha('source_plan.json'),
    'label_rules_sha256':sha('label_rules.json'), 'capture_index_sha256':sha('capture_index.json'),
    'label_adjudication_sha256':sha('label_adjudication.json'), 'baseline_code_sha':master['baseline_code_sha'],
    'rules':rules, 'adjudication_method':adjudication['method'],
    'cases':copy.deepcopy(adjudication['cases']), 'counts':copy.deepcopy(adjudication['counts']),
    'identical_projected_state_groups':copy.deepcopy(adjudication['identical_projected_state_groups']),
    'current_corpus_tev_outputs_seen':False, 'external_inference_calls_by_adjudicator':0,
    'freeze_rule':'Labels are frozen before any Tev calls. Failed captures retain labels=None and never count as measured abstentions. Any supplemental shadow diagnostic is a separate protocol.',
}
for record in labels['cases']:
    record['mapping_reason'] = record['rationale']
save('labels.json', labels)
print(json.dumps({'capture_index_sha256':sha('capture_index.json'),'labels_sha256':sha('labels.json'),'frozen_at':labels['frozen_at'],'label_adjudication_sha256':sha('label_adjudication.json'),'counts':labels['counts']}))
