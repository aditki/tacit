"""Freeze public existing telemetry and a neutral question before baseline capture."""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import subprocess
import sys
import time
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

CODE = Path('/private/tmp/tacit-acquisition-implementation')
SOURCE = Path('/Users/adityamudunuri/src/tacit')
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE))
from demo.rebase_otlp_metrics import _records, _timestamp_values, shift_timestamps


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(',', ':')) + '\n').encode()


def sha(body):
    return hashlib.sha256(body).hexdigest()


def write(path, body):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(body)


def get(path):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open('http://127.0.0.1:11434' + path, timeout=10) as response:
        assert response.url == 'http://127.0.0.1:11434' + path
        return json.loads(response.read(1024 * 1024))


plan_bytes = Path('/private/tmp/tacit-scenario-tev-corpus-plan.json').read_bytes()
assert sha(plan_bytes) == 'ab0b016ffe90185694e34e9fb806d24942bda689d1eb1b01721f996f0502058f'
plan = json.loads(plan_bytes)
write(ROOT / 'source_plan.json', plan_bytes)
version = get('/api/version')['version']
model_name = 'qwen3-coder:30b-a3b-q4_K_M'
model = next(item for item in get('/api/tags')['models'] if item['name'] == model_name)
baseline_sha = subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], text=True).strip()
assert baseline_sha.startswith('1af49fd')
end_ms = time.time_ns() // 1_000_000 - 5_000
prompt = plan['common_prompt_policy']['candidate_text']
rules = {
    'schema_version': 'scenario-priority-label-rules/1',
    'task': 'Next inspection priority justified by the recorded packet, never root cause or a numeric condition.',
    'hidden_truth': 'Dataset injections, source condition, timing metadata and expected causes stay scorer-only.',
    'negative_controls': 'Healthy and symptom-only/resource-absent controls require insufficient priority evidence.',
    'positive_cases': 'Resolve predeclared source-plan role aliases only to real captured candidates with their own observation links. Availability without a priority-discriminating fact is insufficient; do not infer an anomaly from nonempty queries.',
    'missing_capture': 'Retain failed attempts in coverage; never manufacture a contract, baseline or candidate.',
    'no_calls': 'Carry forward captured policy abstention; zero/one admissible candidates remain deterministic.',
    'mapping_independence': 'Do not use baseline rank, score, confidence or any Tev output to assign labels.',
    'review': 'Author adjudication against frozen source rules and visible captured facts; no claim of independent human labels.',
}
write(ROOT / 'label_rules.json', canonical(rules))
cases = []
for case in plan['cases']:
    case_id = case['case_id']
    output = ROOT / 'input_replays' / (case_id + ('.prom.gz' if case['dataset'] == 'gamma' else '.jsonl.gz'))
    output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if case['dataset'] == 'gamma':
        source = case['samples_source']
        body = (SOURCE / source['path']).read_bytes()
        assert sha(body) == source['sha256'] and len(body) == source['bytes']
        lines = body.splitlines()
        stamps = [int(line.rsplit(b' ', 1)[1]) for line in lines if line.strip()]
        before = hashlib.sha256()
        after = hashlib.sha256()
        shift = end_ms - max(stamps)
        pieces = []
        for line in lines:
            if not line.strip():
                continue
            prefix, stamp = line.rsplit(b' ', 1)
            before.update(prefix + b'\n')
            rewritten = prefix + b' ' + str(int(stamp) + shift).encode() + b'\n'
            after.update(rewritten.rsplit(b' ', 1)[0] + b'\n')
            pieces.append(rewritten)
        assert before.digest() == after.digest()
        raw = b''.join(pieces)
        write(output, gzip.compress(raw, mtime=0))
        transform = {'kind': 'constant_timestamp_offset_ms', 'offset_ms': shift,
                     'source_stored_min_ms': min(stamps), 'source_stored_max_ms': max(stamps),
                     'replay_min_ms': min(stamps) + shift, 'replay_max_ms': end_ms,
                     'non_timestamp_sha256': before.hexdigest(), 'sample_count': len(stamps)}
        source_records = [source, case['source_manifest']]
        for record in source_records:
            selected = (SOURCE / record['path']).read_bytes()
            assert len(selected) == record['bytes'] and sha(selected) == record['sha256']
    else:
        source = next(record for record in case['sources'] if record['path'].endswith('.tar.gz'))
        archive = SOURCE / source['path']
        assert sha(archive.read_bytes()) == source['sha256']
        stamps = [stamp for record in _records(archive) for stamp in _timestamp_values(record) if stamp > 0]
        shift = end_ms * 1_000_000 - max(stamps)
        count = 0
        fd = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as destination:
            with gzip.GzipFile(filename='', fileobj=destination, mode='wb', mtime=0) as compressed:
                for record in _records(archive):
                    compressed.write(canonical(shift_timestamps(record, shift)))
                    count += 1
        assert count <= 1000
        raw = gzip.decompress(output.read_bytes())
        transform = {'kind': 'existing_otlp_constant_timestamp_offset_ns', 'offset_ns': shift,
                     'source_min_ns': min(stamps), 'source_max_ns': max(stamps),
                     'replay_max_ns': end_ms * 1_000_000, 'record_count': count,
                     'transform_source_sha256': sha((CODE / 'demo/rebase_otlp_metrics.py').read_bytes())}
        source_records = case['sources']
    compressed = output.read_bytes()
    assert len(compressed) <= 8 * 1024 * 1024 and len(raw) <= 64 * 1024 * 1024
    cases.append({
        'case_id': case_id, 'incident_id': case['incident_id'], 'family_id': case['family_id'],
        'class': case['case_class'], 'dataset': case['dataset'],
        'format': 'prometheus' if case['dataset'] == 'gamma' else 'otlp_jsonl', 'compression': 'gzip',
        'metric_path': str(output.relative_to(ROOT)), 'metric_sha256': sha(compressed),
        'compressed_bytes': len(compressed), 'expanded_bytes': len(raw), 'expanded_sha256': sha(raw),
        'transform': transform, 'source_records': source_records,
    })

manifest = {
    'schema_version': 'scenario-source-manifest/1', 'baseline_code_sha': baseline_sha,
    'model': {'name': model_name, 'digest': model['digest'], 'server_version': version, 'details': model['details']},
    'prompt': prompt, 'frozen_end_ms': end_ms, 'case_count': len(cases), 'cases': cases,
    'label_rules_sha256': sha(canonical(rules)), 'source_plan_sha256': sha(plan_bytes),
}
write(ROOT / 'source_manifest.json', canonical(manifest))
write(ROOT / 'source_freeze.json', canonical({
    'schema_version': 'scenario-source-freeze/1', 'source_manifest_sha256': sha(canonical(manifest)),
    'source_plan_sha256': sha(plan_bytes), 'label_rules_sha256': sha(canonical(rules)),
    'frozen_at': datetime.now(UTC).isoformat(), 'baseline_runs_started': 0,
}))
print(json.dumps({'cases': len(cases), 'frozen_end_ms': end_ms, 'source_manifest_sha256': sha(canonical(manifest)),
                  'total_compressed_bytes': sum(case['compressed_bytes'] for case in cases), 'model': model_name}))
