"""Assemble the frozen public corpus from an explicit file allowlist; no acquisition.

Operator-only: run after the collection owner declares every ledger final. This
module has no network, database, model, shell, Docker, or production imports.
Frozen source and capture bytes are copied exactly. The ClickStack raw inputs
remain external because their redistribution terms could not be verified.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
import re
import stat
import tarfile
from itertools import zip_longest
from pathlib import Path, PurePosixPath

PREFIX = "scenario_tev_corpus_v1/"
MAX_MEMBER = 32 * 1024 * 1024
MAX_TOTAL = 256 * 1024 * 1024
MAX_MEMBERS = 1000
MAX_OTLP = 64 * 1024 * 1024
CASE = re.compile(r"[a-z][a-z0-9_]{0,95}\Z")
GAMMA_URL = "https://www.kaggle.com/api/v1/datasets/view/gagansomashekar/microservices-bottleneck-detection-dataset"
CLICK_URL = "https://storage.googleapis.com/hyperdx/sample.tar.gz"


def canonical(value):
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode()


def sha(body):
    return hashlib.sha256(body).hexdigest()


def regular(path, limit=MAX_MEMBER):
    assert not path.is_symlink() and stat.S_ISREG(path.stat().st_mode), path
    with path.open("rb") as stream:
        body = stream.read(limit + 1)
    assert len(body) <= limit, path
    return body


def relative(root, name):
    selected = PurePosixPath(name)
    assert (
        str(selected) == name
        and not selected.is_absolute()
        and ".." not in selected.parts
    )
    path = root / name
    assert path.resolve() == root.resolve() / name, "Symlink in input path"
    return path


def timestamp_attestation(base, admitted, offset_ns, expected_end_ns):
    """Locally reverify the omitted files; this is an attestation, not portable proof."""
    expanded = [hashlib.sha256(), hashlib.sha256()]
    totals = [0, 0]
    non_time = [hashlib.sha256(), hashlib.sha256()]
    records = 0
    count, maximum = 0, 0

    def normalize(before, after):
        nonlocal count, maximum
        assert type(before) is type(after), "OTLP type changed"
        if isinstance(before, dict):
            assert before.keys() == after.keys()
            left, right = {}, {}
            for key in before:
                value, target = before[key], after[key]
                if key.lower().endswith("timeunixnano"):
                    assert type(value) in (str, int) and type(target) is type(value)
                    assert int(target) == (int(value) + offset_ns if int(value) else 0)
                    if int(value):
                        count += 1
                        maximum = max(maximum, int(target))
                    left[key] = right[key] = "<timestamp>"
                else:
                    left[key], right[key] = normalize(value, target)
            return left, right
        if isinstance(before, list):
            assert len(before) == len(after)
            pairs = [normalize(a, b) for a, b in zip(before, after, strict=True)]
            return [a for a, _ in pairs], [b for _, b in pairs]
        assert before == after, "Non-time OTLP value changed"
        return before, after

    with gzip.GzipFile(fileobj=io.BytesIO(base)) as originals, gzip.GzipFile(
        fileobj=io.BytesIO(admitted)
    ) as shifted:
        for before, after in zip_longest(originals, shifted):
            assert before is not None and after is not None
            assert len(before) <= 1024 * 1024 and len(after) <= 1024 * 1024
            records += 1
            assert records <= 1000
            for position, body in enumerate((before, after)):
                totals[position] += len(body)
                assert totals[position] <= MAX_OTLP
                expanded[position].update(body)
            old, new = normalize(json.loads(before), json.loads(after))
            non_time[0].update(canonical(old) + b"\n")
            non_time[1].update(canonical(new) + b"\n")
    assert count > 0 and maximum == expected_end_ns
    assert non_time[0].digest() == non_time[1].digest()
    return {
        "record_count": records,
        "timestamp_count": count,
        "admitted_max_timestamp_ns": maximum,
        "base_non_time_sha256": non_time[0].hexdigest(),
        "admitted_non_time_sha256": non_time[1].hexdigest(),
    }, [
        {"expanded_bytes": n, "expanded_sha256": d.hexdigest()}
        for n, d in zip(totals, expanded, strict=True)
    ]


def assemble(root, output, acquisition, original):
    members = {}

    def add(name, body):
        selected = PurePosixPath(name)
        assert (
            str(selected) == name
            and not selected.is_absolute()
            and ".." not in selected.parts
        )
        assert name not in members and len(body) <= MAX_MEMBER
        assert not name.endswith((".db", ".sqlite", ".log", ".env", ".gguf", ".pyc"))
        members[name] = body
        assert (
            len(members) <= MAX_MEMBERS and sum(map(len, members.values())) <= MAX_TOTAL
        )

    def copy(name):
        body = regular(relative(root, name))
        add(name, body)
        return body

    root_names = (
        "source_manifest.json",
        "source_plan.json",
        "source_freeze.json",
        "label_rules.json",
        "labels.json",
        "label_adjudication.json",
        "capture_index.json",
        "collection.json",
        "stack_teardown.json",
        "acquisition_replay_audit.json",
        "invalid_v1/invalid_cohort.json",
        "invalid_v1/source_manifest.json",
        "invalid_v1/source_freeze.json",
        "experiment/manifest.json",
        "prepared/projection.json",
        "prepared/candidate_map.json",
        "prepared/index.json",
        "responses/collection.json",
        "scores/report.json",
        "scores/rows.jsonl",
    )
    for name in root_names:
        copy(name)
    source = json.loads(members["source_manifest.json"])
    index = json.loads(members["capture_index.json"])
    assert len(source["cases"]) == len(index["cases"]) == 13
    by_id = {item["case_id"]: item for item in index["cases"]}
    assert len(by_id) == 13
    case_names = (
        "datasource.json",
        "ownership.json",
        "events.json",
        "capture_index.json",
        "import.json",
        "admission_freeze.json",
        "execution_manifest.json",
        "history_stats.json",
        "investigation.json",
        "model_before.json",
        "model_after.json",
        "response.json",
        "baseline_admission.json",
        "runs.json",
        "run_audit.json",
    )
    for case in source["cases"]:
        cid = case["case_id"]
        assert CASE.fullmatch(cid)
        entry = by_id[cid]
        for leaf in case_names:
            copy(f"captures/{cid}/{leaf}")
        copy(f"admitted_replays/{cid}.admission.json")
        if entry["capture_available"]:
            for leaf in ("assessment.tar.gz", "snapshot.json", "contract.json"):
                copy(f"captures/{cid}/{leaf}")
        if case["dataset"] == "gamma":
            copy(case["metric_path"])
            copy(entry["admitted_replay"]["metric_path"])
        else:
            assert cid == "clickstack_payment_cache" and case["dataset"] == "clickstack"

    operator_paths = {
        "publish_corpus.py": Path(__file__),
        "freeze_sources.py": original / "freeze_sources.py",
        "rebase_otlp_metrics.py": acquisition / "demo/rebase_otlp_metrics.py",
        **{
            name: root / name
            for name in (
                "capture_baselines.py",
                "run_baselines.py",
                "test_clock_regression.py",
                "adjudicate_labels.py",
                "finalize_labels.py",
                "freeze_experiment.py",
                "verify_acquisition_replay.py",
            )
        },
    }
    for name, path in operator_paths.items():
        add("operators/" + name, regular(path))

    # Only protocol-pinned shadow files are admitted. No raw endpoint inventory,
    # collection logs, executable model weights, or runtime state are copied.
    for name in (
        "protocol.json",
        "protocol_notes.md",
        "shadow_diagnostic.py",
        "test_shadow_diagnostic.py",
        "collect_shadow.py",
    ):
        copy("shadow_operator/" + name)
    for name in (
        "protocol.json",
        "identity.json",
        "collection_start.json",
        "collection.json",
    ):
        copy("shadow/" + name)
    shadow = json.loads(copy("shadow/prepared/manifest.json"))
    copy("shadow/prepared/complete.json")
    assert len(shadow["cases"]) == 9
    for case in shadow["cases"]:
        cid = case["case_id"]
        assert CASE.fullmatch(cid)
        copy(f"shadow/prepared/requests/{cid}.json")
        copy(f"shadow/responses/{cid}.tev.primary.a1.json")
        copy(f"shadow/raw/{cid}.tev.primary.a1.json")
    copy("shadow/scores/report.json")
    copy("shadow/scores/complete.json")
    copy("shadow/accounting.json")

    apache = regular(root / "publication_assets/APACHE-2.0.txt")
    assert (
        b"Apache License" in apache and b"APPENDIX" in apache and len(apache) == 11358
    )
    add("licenses/APACHE-2.0.txt", apache)
    metadata = regular(root / "publication_assets/gamma_kaggle_metadata.json")
    published = json.loads(metadata)
    assert published["id"] == 4451758 and published["licenseName"] == "Apache 2.0"
    add("licenses/gamma_kaggle_metadata.json", metadata)
    notice = (
        "GAMMA derived telemetry fixture\n\n"
        "Source: Microservices Bottleneck Localization Dataset, Gagan Somashekar, Kaggle dataset 4451758, version 1.\n"
        "https://www.kaggle.com/datasets/gagansomashekar/microservices-bottleneck-detection-dataset\n"
        "Dataset metadata publishes Apache 2.0; the source archive supplied no separate NOTICE file.\n\n"
        "Requested citation: Gagan Somashekar, Anurag Dutt, Mainak Adak, Tania Lorido Botran, and Anshul Gandhi.\n"
        "GAMMA: Graph Neural Network-Based Multi-Bottleneck Localization for Microservices Applications.\n"
        "The ACM Web Conference 2024. https://doi.org/10.1145/3589334.3645665\n\n"
        "Modifications by Tacit evaluation operators, November 2026: selected bounded existing fault, healthy, and\n"
        "symptom-only source windows. The existing GAMMA pilot conversion normalizes source CSV metric names\n"
        "and adds Prometheus labels. The V2 replay then applies fixed timestamp offsets and gzip, preserving\n"
        "all names, labels and numeric values from those normalized Prometheus inputs. The frozen source manifest\n"
        "records source hashes, sample counts, and transforms. This is a small development diagnostic, not the full dataset.\n"
    ).encode()
    add("licenses/GAMMA-NOTICE.txt", notice)
    add("licenses/TACIT-MIT.txt", regular(acquisition / "LICENSE"))
    add(
        "data_licenses.json",
        canonical(
            {
                "schema_version": "scenario-data-licenses/1",
                "gamma": {
                    "license": "Apache-2.0",
                    "license_evidence_url": GAMMA_URL,
                    "metadata_path": "licenses/gamma_kaggle_metadata.json",
                    "metadata_sha256": sha(metadata),
                    "license_path": "licenses/APACHE-2.0.txt",
                    "license_sha256": sha(apache),
                    "notice_path": "licenses/GAMMA-NOTICE.txt",
                    "notice_sha256": sha(notice),
                },
                "clickstack": {
                    "redistribution_license_verified": False,
                    "raw_timeseries_included": False,
                    "official_sample_docs": "https://clickhouse.com/docs/clickstack/example-datasets/sample-data",
                    "reason": "Official sample is downloadable; archive and object metadata contain no data license. Software licensing alone does not bind these bytes. Existing frozen source-plan license assumptions are retained as historical records, not adopted for redistribution.",
                },
            }
        ),
    )

    case = next(
        item
        for item in source["cases"]
        if item["case_id"] == "clickstack_payment_cache"
    )
    entry = by_id[case["case_id"]]
    admission = entry["admitted_replay"]
    base = regular(relative(root, case["metric_path"]))
    admitted = regular(relative(root, admission["metric_path"]))
    assert (
        sha(base) == case["metric_sha256"]
        and sha(admitted) == admission["metric_sha256"]
    )
    proof, expansions = timestamp_attestation(
        base,
        admitted,
        admission["offset_ms"] * 1_000_000,
        admission["end_ms"] * 1_000_000,
    )
    raw_refs = []
    for original, body, expanded in zip(
        (case, admission), (base, admitted), expansions, strict=True
    ):
        assert expanded["expanded_sha256"] == original["expanded_sha256"]
        assert expanded["expanded_bytes"] == original["expanded_bytes"]
        raw_refs.append(
            {
                "path": original["metric_path"],
                "sha256": sha(body),
                "compressed_bytes": len(body),
                "gzip_header_hex": body[:10].hex(),
                **expanded,
            }
        )
    admission_ref = {
        "path": "captures/clickstack_payment_cache/admission_freeze.json",
        "sha256": sha(
            members["captures/clickstack_payment_cache/admission_freeze.json"]
        ),
    }
    operator_refs = [
        {"path": "operators/" + name, "sha256": sha(members["operators/" + name])}
        for name in (
            "publish_corpus.py",
            "freeze_sources.py",
            "capture_baselines.py",
            "rebase_otlp_metrics.py",
        )
    ]
    proof.update(
        {
            "schema_version": "scenario-local-external-transform-attestation/1",
            "case_id": case["case_id"],
            "independent_timestamp_reverification": False,
            "local_timestamp_transform_reverified": True,
            "method": "Local streamwise type/key/value equality plus exact constant timestamp delta; raw files are omitted from this published artifact.",
            "source_freeze_sha256": sha(members["source_freeze.json"]),
            "admission_record_sha256": admission_ref["sha256"],
            "base_input": raw_refs[0],
            "admitted_input": raw_refs[1],
            "offset_ns": admission["offset_ms"] * 1_000_000,
            "operator_sources": operator_refs,
        }
    )
    proof_path = "external_transform_proofs/clickstack_payment_cache.json"
    add(proof_path, canonical(proof))
    archive_ref = next(
        item for item in case["source_records"] if item["path"].endswith(".tar.gz")
    )
    add(
        "external_inputs.json",
        canonical(
            {
                "schema_version": "scenario-external-inputs/1",
                "source_freeze_sha256": sha(members["source_freeze.json"]),
                "capture_index_sha256": sha(members["capture_index.json"]),
                "cases": [
                    {
                        "case_id": case["case_id"],
                        "dataset": "clickstack",
                        "omission_reason": "Data redistribution license unverified; full raw replay inputs remain local.",
                        "base_input": raw_refs[0],
                        "admitted_input": raw_refs[1],
                        "omitted_members": [item["path"] for item in raw_refs],
                        "admission_record": admission_ref,
                        "transform_proof": {
                            "path": proof_path,
                            "sha256": sha(members[proof_path]),
                        },
                        "source_archive": {
                            **archive_ref,
                            "url": CLICK_URL,
                            "member": "metrics.json",
                            "member_bytes": 36448128,
                            "member_sha256": "5e7653e751595165bfedf5e7993f54bd393eabc39ddb28c894b0e023721dc1f8",
                        },
                        "retrieval_recipe": {
                            "independent_timestamp_reverification": False,
                            "steps": [
                                "Retrieve the official sample URL separately and verify source_archive byte count and SHA-256 before reading metrics.json.",
                                "Verify the metrics.json member hash. Read OTLP JSONL using the recorded rebase helper; apply the source manifest's fixed offset_ns and canonical UTF-8 JSON with newline.",
                                "Write base gzip with filename empty and mtime zero. Verify compressed and expanded base hashes before any use.",
                                "Apply admission offset_ms times 1000000 to timestamp leaves only. Preserve every other value; write canonical JSONL and gzip.compress(mtime=0). Verify admitted expanded and compressed hashes.",
                                "The recorded exact gzip headers bind the original CPython gzip encoding. Re-encoding on another Python/zlib platform may differ; never accept a mismatching SHA as the frozen input.",
                            ],
                            "base_transform": case["transform"],
                            "admission_offset_ms": admission["offset_ms"],
                            "operator_sources": operator_refs,
                        },
                    }
                ],
            }
        ),
    )
    # Inventory commits every copied byte without changing any source record.
    add(
        "publication_inventory.json",
        canonical(
            {
                "schema_version": "scenario-publication-inventory/1",
                "format": "regular-ustar-gzip-mtime-zero",
                "members": [
                    {"path": name, "bytes": len(body), "sha256": sha(body)}
                    for name, body in sorted(members.items())
                ],
                "raw_source_mutations": False,
            }
        ),
    )
    tar = io.BytesIO()
    with tarfile.open(fileobj=tar, mode="w", format=tarfile.USTAR_FORMAT) as target:
        for name, body in sorted(members.items()):
            item = tarfile.TarInfo(PREFIX + name)
            item.size, item.mode, item.mtime = len(body), 0o600, 0
            item.uid = item.gid = 0
            item.uname = item.gname = ""
            target.addfile(item, io.BytesIO(body))
    assert len(tar.getvalue()) <= MAX_TOTAL
    compressed = io.BytesIO()
    with gzip.GzipFile(filename="", fileobj=compressed, mode="wb", mtime=0) as target:
        target.write(tar.getvalue())
    body = compressed.getvalue()
    assert len(body) <= 64 * 1024 * 1024
    output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as target:
        target.write(body)
    return {
        "archive": str(output),
        "bytes": len(body),
        "sha256": sha(body),
        "members": len(members),
        "expanded_member_bytes": sum(map(len, members.values())),
        "ustar_bytes": len(tar.getvalue()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--acquisition",
        type=Path,
        default=Path("/private/tmp/tacit-acquisition-implementation"),
    )
    parser.add_argument(
        "--original",
        type=Path,
        default=Path("/private/tmp/tacit-scenario-corpus-20261118"),
    )
    args = parser.parse_args()
    print(
        json.dumps(
            assemble(args.root, args.out, args.acquisition, args.original),
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
