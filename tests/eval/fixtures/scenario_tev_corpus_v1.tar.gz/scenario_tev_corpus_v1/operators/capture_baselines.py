"""External operator: one frozen scenario, one actual Tacit run, owned local services.

The caller owns Docker creation/removal and resets its fresh volumes between
invocations. This program never deletes VM data, changes settings globally,
teaches mappings, retries a pipeline, or unloads an Ollama model.
"""

from __future__ import annotations

import argparse
import asyncio
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx

if not __debug__:
    raise RuntimeError("baseline capture requires validation assertions enabled")

CWD_A = Path("/private/tmp/tacit-acquisition-implementation")
sys.path.insert(0, str(CWD_A))

from tacit.errors import AUTHORITY_BOUNDARY_ERRORS, safe_failure_diagnostics
from tacit.investigation_bundle import export_investigation_bundle
from tacit.models.schemas import DashRequest
from tacit.pipeline import run_pipeline
from tests.eval.cold_isolation import (
    LocalEvaluationEndpoints,
    cold_isolation,
    require_local_endpoint,
)

TENANT = "scenario-tev-evaluation"
DATASOURCE_UID = "scenario-telemetry"
EXPECTED_PROJECT = "tacit-tev-corpus-20261118"
MAX_SOURCE_BYTES = 64 * 1024 * 1024
MAX_PROM_BYTES = 8 * 1024 * 1024
MAX_OTLP_BYTES = 64 * 1024 * 1024
MAX_OTLP_LINE = 1024 * 1024
MAX_OTLP_RECORDS = 1000
MAX_JSON_RESPONSE = 2 * 1024 * 1024
CASE_ID = re.compile(r"[a-z][a-z0-9_-]{0,95}\Z")
TIMING_PROFILE = "per-case-admission-clock/1"


def verify_time_only_transform(
    base_body: bytes,
    admitted_body: bytes,
    replay_format: str,
    offset_ms: int,
    end_ms: int,
    now_ms: int,
) -> dict:
    """Prove a constant time shift and exact preservation of all other facts."""
    assert all(type(value) is int for value in (offset_ms, end_ms, now_ms))
    freshness = now_ms - end_ms
    assert 0 <= freshness <= 60_000, "admitted replay clock is stale or in the future"
    limit = MAX_PROM_BYTES if replay_format == "prometheus" else MAX_OTLP_BYTES
    assert len(base_body) <= limit and len(admitted_body) <= limit
    base_lines, admitted_lines = base_body.splitlines(
        keepends=True
    ), admitted_body.splitlines(keepends=True)
    assert len(base_lines) == len(admitted_lines), "replay record count changed"
    timestamps: list[int] = []

    def same_json(base: Any, admitted: Any) -> None:
        assert type(base) is type(admitted), "non-time JSON type changed"
        if isinstance(base, dict):
            assert set(base) == set(admitted), "OTLP keys changed"
            for key, value in base.items():
                target = admitted[key]
                if key.lower().endswith("timeunixnano"):
                    assert (
                        type(value) in (int, str) and type(target) is str
                    ), "invalid OTLP timestamp type"
                    assert str(int(value)) == str(value) and str(int(target)) == target
                    assert (
                        int(target) == int(value) + offset_ms * 1_000_000
                    ), "nonconstant OTLP time shift"
                    timestamps.append(int(target))
                else:
                    same_json(value, target)
        elif isinstance(base, list):
            assert len(base) == len(admitted), "OTLP array changed"
            for item, target in zip(base, admitted, strict=True):
                same_json(item, target)
        else:
            assert base == admitted, "non-time OTLP value changed"

    if replay_format == "prometheus":
        for base, admitted in zip(base_lines, admitted_lines, strict=True):
            if not base.strip():
                assert base == admitted
                continue
            before, old_stamp = base.rstrip(b"\n").rsplit(b" ", 1)
            after, new_stamp = admitted.rstrip(b"\n").rsplit(b" ", 1)
            assert before == after and base.endswith(b"\n") == admitted.endswith(
                b"\n"
            ), "non-time Prometheus bytes changed"
            assert (
                int(new_stamp) == int(old_stamp) + offset_ms
            ), "nonconstant Prometheus time shift"
            timestamps.append(int(new_stamp))
        assert (
            timestamps and max(timestamps) == end_ms
        ), "admitted Prometheus end mismatch"
    else:
        assert replay_format == "otlp_jsonl" and len(base_lines) <= MAX_OTLP_RECORDS
        for base, admitted in zip(base_lines, admitted_lines, strict=True):
            assert len(base) <= MAX_OTLP_LINE and len(admitted) <= MAX_OTLP_LINE
            if not base.strip():
                assert base == admitted
                continue
            same_json(json.loads(base), json.loads(admitted))
        assert (
            timestamps and max(timestamps) == end_ms * 1_000_000
        ), "admitted OTLP end mismatch"
    return {
        "timing_profile": TIMING_PROFILE,
        "replay_freshness_ms": freshness,
        "sample_count": len(timestamps),
        "record_count": len(base_lines),
        "admitted_end_ms": end_ms,
        "offset_ms": offset_ms,
        "time_only_transform_verified": True,
    }


def expanded_replay(path: Path, case: dict) -> bytes:
    opener = gzip.open if case.get("compression", "none") == "gzip" else open
    limit = MAX_PROM_BYTES if case["format"] == "prometheus" else MAX_OTLP_BYTES
    with opener(path, "rb") as stream:
        body = stream.read(limit + 1)
    assert 0 < len(body) <= limit, "expanded replay byte limit"
    return body


def sha_file(path: Path) -> str:
    assert (
        path.is_file() and not path.is_symlink()
    ), "source must be a regular selected file"
    assert path.stat().st_size <= MAX_SOURCE_BYTES, "source byte limit"
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_bytes(path: Path, body: bytes) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(body)


def write_json(path: Path, value: Any) -> None:
    write_bytes(
        path,
        (
            json.dumps(
                value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False
            )
            + "\n"
        ).encode(),
    )


def response_json(response: httpx.Response) -> Any:
    response.raise_for_status()
    assert len(response.content) <= MAX_JSON_RESPONSE, "operator response limit"
    return response.json()


def validate_inputs(manifest_path: Path) -> tuple[dict, dict, dict, Path, bytes, bytes]:
    manifest_body = manifest_path.read_bytes()
    assert len(manifest_body) <= 1024 * 1024, "execution manifest limit"
    manifest = json.loads(manifest_body)
    assert len(manifest["cases"]) == 1, "one case per fresh-service invocation"
    assert (
        manifest["project"] == EXPECTED_PROJECT
    ), "dedicated evaluation project required"
    endpoints = manifest["endpoints"]
    for name in ("grafana_url", "vm_url", "otel_url", "llm_api_base"):
        require_local_endpoint(endpoints[name], name)

    ownership_path = manifest_path.parent / "ownership.json"
    ownership_body = ownership_path.read_bytes()
    assert (
        hashlib.sha256(ownership_body).hexdigest() == manifest["ownership_sha256"]
    ), "ownership bytes changed"
    ownership = json.loads(ownership_body)
    assert ownership["project"] == manifest["project"], "project ownership mismatch"
    assert (
        isinstance(ownership.get("run_id"), str) and ownership["run_id"]
    ), "ownership nonce missing"
    if "run_id" in manifest:
        assert manifest["run_id"] == ownership["run_id"], "ownership nonce mismatch"
    assert ownership["vm_url"].rstrip("/") == endpoints["vm_url"].rstrip(
        "/"
    ), "VM ownership mismatch"
    for name in ("grafana_url", "otel_url"):
        if name in ownership:
            assert ownership[name].rstrip("/") == endpoints[name].rstrip(
                "/"
            ), "endpoint ownership mismatch"
    assert ownership.get("datasource_url"), "owned datasource URL required"

    master_name = manifest.get("master_manifest_path", manifest.get("master_path"))
    assert master_name, "frozen master manifest required"
    master_path = Path(master_name)
    if not master_path.is_absolute():
        master_path = manifest_path.parent / master_path
    master_body = master_path.read_bytes()
    assert len(master_body) <= 1024 * 1024
    assert (
        hashlib.sha256(master_body).hexdigest() == manifest["master_sha256"]
    ), "master bytes changed"
    master = json.loads(master_body)
    assert 1 <= len(master["cases"]) <= 13
    for name in ("baseline_code_sha", "model", "prompt", "timing_profile"):
        assert manifest[name] == master[name], "scientific execution input changed"
    assert master["timing_profile"] == TIMING_PROFILE
    case = manifest["cases"][0]
    source_case = {
        key: value for key, value in case.items() if key != "admitted_replay"
    }
    assert (
        sum(item == source_case for item in master["cases"]) == 1
    ), "case is not the frozen master case"
    assert CASE_ID.fullmatch(case["case_id"]), "invalid case ID"
    assert case["format"] in {"prometheus", "otlp_jsonl"}
    assert case.get("compression", "none") in {"none", "gzip"}
    base_path = Path(case["metric_path"])
    if not base_path.is_absolute():
        base_path = master_path.parent / base_path
    assert sha_file(base_path) == case["metric_sha256"], "base metric bytes changed"
    admission = case["admitted_replay"]
    metric_path = Path(admission["metric_path"])
    if not metric_path.is_absolute():
        metric_path = master_path.parent / metric_path
    record_path = metric_path.parent / (case["case_id"] + ".admission.json")
    record_body = record_path.read_bytes()
    assert len(record_body) <= 1024 * 1024
    assert (
        hashlib.sha256(record_body).hexdigest() == admission["admission_freeze_sha256"]
    ), "admission record changed"
    record = json.loads(record_body)
    assert record == {
        key: value
        for key, value in admission.items()
        if key != "admission_freeze_sha256"
    }, "admission fields changed"
    assert record["schema_version"] == "scenario-replay-admission/1"
    assert (
        record["timing_profile"] == TIMING_PROFILE
        and record["case_id"] == case["case_id"]
    )
    assert record["base_metric_path"] == case["metric_path"]
    assert record["base_metric_sha256"] == case["metric_sha256"]
    assert record["source_end_ms"] == master["frozen_end_ms"]
    assert record["end_ms"] == record["source_end_ms"] + record["offset_ms"]
    assert (
        sha_file(metric_path) == admission["metric_sha256"]
    ), "admitted metric bytes changed"
    base_body, admitted_body = expanded_replay(base_path, case), expanded_replay(
        metric_path, case
    )
    assert hashlib.sha256(base_body).hexdigest() == case["expanded_sha256"]
    assert hashlib.sha256(admitted_body).hexdigest() == admission["expanded_sha256"]
    assert len(admitted_body) == admission["expanded_bytes"]
    verify_time_only_transform(
        base_body,
        admitted_body,
        case["format"],
        record["offset_ms"],
        record["end_ms"],
        time.time_ns() // 1_000_000,
    )

    current_sha = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=CWD_A,
        check=True,
        text=True,
        capture_output=True,
        timeout=5,
    ).stdout.strip()
    assert current_sha == manifest["baseline_code_sha"], "baseline checkout changed"
    return manifest, ownership, case, metric_path, manifest_body, ownership_body


def check_model(client: httpx.Client, manifest: dict) -> dict:
    base = manifest["endpoints"]["llm_api_base"].rstrip("/")
    model = manifest["model"]
    version = response_json(client.get(base + "/api/version"))["version"]
    assert version == model["server_version"], "Ollama server identity changed"
    tags = response_json(client.get(base + "/api/tags"))["models"]
    selected = [item for item in tags if item["name"] == model["name"]]
    assert len(selected) == 1, "baseline model absent or ambiguous"
    assert selected[0]["digest"].removeprefix("sha256:") == model[
        "digest"
    ].removeprefix("sha256:"), "model artifact changed"
    return {"server_version": version, "model": selected[0]}


def check_datasource(client: httpx.Client, manifest: dict, ownership: dict) -> dict:
    base = manifest["endpoints"]["grafana_url"].rstrip("/")
    sources = response_json(client.get(base + "/api/datasources"))
    assert (
        isinstance(sources, list) and len(sources) == 1
    ), "fresh Grafana must have exactly one datasource"
    datasource = sources[0]
    assert (
        datasource["uid"] == DATASOURCE_UID and datasource["type"] == "prometheus"
    ), "unexpected datasource"
    assert datasource["url"].rstrip("/") == ownership["datasource_url"].rstrip(
        "/"
    ), "datasource target is not owned VM"
    return datasource


def vm_names(client: httpx.Client, manifest: dict) -> list:
    base = manifest["endpoints"]["vm_url"].rstrip("/")
    result = response_json(
        client.get(base + "/api/v1/label/__name__/values", params={"nocache": "1"})
    )
    assert result.get("status") == "success" and isinstance(result.get("data"), list)
    return result["data"]


def import_metrics(
    client: httpx.Client, manifest: dict, case: dict, metric_path: Path
) -> dict:
    assert (
        vm_names(client, manifest) == []
    ), "owned VM metadata is not fresh; caller must reset its volumes"
    opener = gzip.open if case.get("compression", "none") == "gzip" else open
    started = time.monotonic()
    count, expanded = 0, 0
    with opener(metric_path, "rb") as stream:
        if case["format"] == "prometheus":
            body = stream.read(MAX_PROM_BYTES + 1)
            assert 0 < len(body) <= MAX_PROM_BYTES, "Prometheus import byte limit"
            target = (
                manifest["endpoints"]["vm_url"].rstrip("/")
                + "/api/v1/import/prometheus"
            )
            client.post(
                target, content=body, headers={"Content-Type": "text/plain"}
            ).raise_for_status()
            count, expanded = 1, len(body)
        else:
            target = manifest["endpoints"]["otel_url"].rstrip("/") + "/v1/metrics"
            while True:
                body = stream.readline(MAX_OTLP_LINE + 1)
                if not body:
                    break
                assert len(body) <= MAX_OTLP_LINE, "OTLP line byte limit"
                expanded += len(body)
                assert expanded <= MAX_OTLP_BYTES, "OTLP expanded byte limit"
                if not body.strip():
                    continue
                count += 1
                assert count <= MAX_OTLP_RECORDS, "OTLP record limit"
                packet = json.loads(body)
                assert isinstance(packet, dict) and isinstance(
                    packet.get("resourceMetrics"), list
                ), "unexpected OTLP packet"
                response = client.post(
                    target, content=body, headers={"Content-Type": "application/json"}
                )
                response.raise_for_status()
                if response.content:
                    result = response_json(response)
                    assert not result.get(
                        "partialSuccess"
                    ), "partial OTLP import is not a valid baseline"
            assert count, "empty OTLP source"
    assert (
        sha_file(metric_path) == case["admitted_replay"]["metric_sha256"]
    ), "source changed during import"
    deadline = time.monotonic() + 30
    names: list = []
    sample_count = 0.0
    instant_count = 0.0
    base = manifest["endpoints"]["vm_url"].rstrip("/")
    while time.monotonic() < deadline:
        names = vm_names(client, manifest)
        result = response_json(
            client.get(
                base + "/api/v1/query",
                params={
                    "query": 'sum(count_over_time({__name__=~".+"}[5m]))',
                    "nocache": "1",
                },
            )
        )
        values = result.get("data", {}).get("result", [])
        if values:
            sample_count = float(values[0]["value"][1])
        instant = response_json(
            client.get(
                base + "/api/v1/query",
                params={
                    "query": 'count({__name__=~".+"})',
                    "nocache": "1",
                },
            )
        )
        instant_values = instant.get("data", {}).get("result", [])
        if instant_values:
            instant_count = float(instant_values[0]["value"][1])
        if names and sample_count > 0 and instant_count > 0:
            break
        time.sleep(0.25)
    else:
        raise RuntimeError(
            "import did not become queryable under instant and five-minute lookback"
        )
    return {
        "requests": count,
        "expanded_bytes": expanded,
        "metric_names": len(names),
        "samples_last_five_minutes": sample_count,
        "instant_series_count": instant_count,
        "elapsed_ms": round((time.monotonic() - started) * 1000),
        "caps": {
            "compressed_source_bytes": MAX_SOURCE_BYTES,
            "prometheus_expanded_bytes": MAX_PROM_BYTES,
            "otlp_expanded_bytes": MAX_OTLP_BYTES,
            "otlp_line_bytes": MAX_OTLP_LINE,
            "otlp_records": MAX_OTLP_RECORDS,
            "operator_http_timeout_seconds": 15,
        },
    }


def terminal_state(state: Any) -> dict:
    admission = state.runtime_stores.pipeline_admission()
    graph = admission.execution_graph
    result = {
        "root_state": graph.root_state,
        "root_owner_count": graph.root_owner_count,
        "provider_manager_count": graph.provider_manager_count,
        "in_flight": admission.in_flight,
        "retained": admission.retained,
        "blocking_in_flight": admission.blocking_in_flight,
        "service_owner_in_flight": admission.service_owner_in_flight,
    }
    result["terminal_zero"] = result["root_state"] == "closed" and all(
        value == 0 for key, value in result.items() if key != "root_state"
    )
    assert result["terminal_zero"], "existing runtime did not reach terminal zero"
    return result


async def capture(
    manifest: dict, ownership: dict, case: dict, metric_path: Path, output: Path
) -> dict:
    started = time.monotonic()
    with httpx.Client(timeout=15, trust_env=False, follow_redirects=False) as client:
        model_before = check_model(client, manifest)
        datasource = check_datasource(client, manifest, ownership)
        imported = import_metrics(client, manifest, case, metric_path)
        write_json(output / "import.json", imported)
        write_json(output / "model_before.json", model_before)
        write_json(output / "datasource.json", datasource)
        endpoints = LocalEvaluationEndpoints(
            grafana_url=manifest["endpoints"]["grafana_url"],
            llm_api_base=manifest["endpoints"]["llm_api_base"],
            llm_model=manifest["model"]["name"],
        )
        response = None
        failure = None
        index: dict[str, Any] = {
            "project": manifest["project"],
            "ownership_nonce": ownership["run_id"],
            "ownership_sha256": manifest["ownership_sha256"],
            "case_id": case["case_id"],
            "incident_id": case["incident_id"],
            "family_id": case["family_id"],
            "class": case["class"],
            "master_sha256": manifest["master_sha256"],
            "baseline_code_sha": manifest["baseline_code_sha"],
            "model": manifest["model"],
            "measurement_completed": False,
            "capture_available": False,
            "timing_profile": TIMING_PROFILE,
            "admitted_replay": case["admitted_replay"],
        }
        with cold_isolation(
            workdir=output / "runtime", endpoints=endpoints, tenant_id=TENANT
        ) as state:
            try:
                started_ms = time.time_ns() // 1_000_000
                freshness = started_ms - case["admitted_replay"]["end_ms"]
                assert (
                    0 <= freshness <= 60_000
                ), "admission clock expired before first prompt"
                index["baseline_started_at"] = datetime.fromtimestamp(
                    started_ms / 1000, UTC
                ).isoformat()
                index["baseline_started_ms"] = started_ms
                index["replay_freshness_ms"] = freshness
                write_json(
                    output / "baseline_admission.json",
                    {
                        key: index[key]
                        for key in (
                            "timing_profile",
                            "baseline_started_at",
                            "baseline_started_ms",
                            "replay_freshness_ms",
                        )
                    },
                )
                try:
                    response = await run_pipeline(
                        DashRequest(
                            prompt=manifest["prompt"],
                            user_id="scenario-corpus-" + case["case_id"],
                            channel_id="frozen-scenario-baseline",
                            tenant_id=TENANT,
                        ),
                        state.dependencies,
                    )
                except AUTHORITY_BOUNDARY_ERRORS:
                    raise
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    failure = safe_failure_diagnostics(
                        error, reason_code="baseline_pipeline_exception"
                    )
                    write_json(output / "pipeline_failure.json", failure)
                if response is not None:
                    write_json(
                        output / "response.json", response.model_dump(mode="json")
                    )
                    investigation_id = response.investigation_id
                else:
                    records = state.history_store.list_recent(limit=1, tenant_id=TENANT)
                    investigation_id = records[0]["id"] if records else ""
                index["investigation_id"] = investigation_id
                index["pipeline_exception"] = failure
                index["pipeline_status"] = (
                    response.investigation_status
                    if response is not None
                    else "exception"
                )
                index["pipeline_timeout_seconds"] = (
                    state.settings.pipeline_timeout_seconds
                )
                if investigation_id:
                    contract = state.history_store.get_contract(
                        investigation_id, tenant_id=TENANT
                    )
                    if contract is not None:
                        snapshot = state.history_store.get_snapshot(
                            investigation_id,
                            contract.investigation.revision,
                            tenant_id=TENANT,
                        )
                        assert (
                            snapshot is not None
                            and snapshot.baseline_culprit_ranking is not None
                        ), "actual capture lacks baseline"
                        write_json(
                            output / "contract.json",
                            contract.model_dump(mode="json", by_alias=True),
                        )
                        write_json(
                            output / "snapshot.json", snapshot.model_dump(mode="json")
                        )
                        bundle = output / "assessment.tar.gz"
                        export_investigation_bundle(
                            state.history_store,
                            investigation_id,
                            bundle,
                            tenant_id=TENANT,
                        )
                        os.chmod(bundle, 0o600)
                        rebuilt = state.history_store.replay_contract(
                            investigation_id, tenant_id=TENANT
                        )
                        assert rebuilt is not None
                        assert (
                            rebuilt.runtime.output_fingerprint
                            == contract.runtime.output_fingerprint
                        ), "exact replay mismatch"
                        index.update(
                            capture_available=True,
                            revision=contract.investigation.revision,
                            bundle_path=str(bundle),
                            bundle_sha256=sha_file(bundle),
                            input_fingerprint=contract.runtime.input_fingerprint,
                            output_fingerprint=contract.runtime.output_fingerprint,
                            replay_output_fingerprint=rebuilt.runtime.output_fingerprint,
                            baseline_candidates=snapshot.baseline_culprit_ranking.model_dump(
                                mode="json"
                            ),
                            evidence_observations=len(snapshot.evidence_observations),
                        )
                    write_json(
                        output / "investigation.json",
                        state.history_store.get(investigation_id, tenant_id=TENANT),
                    )
                    write_json(
                        output / "runs.json",
                        state.history_store.list_runs(
                            investigation_id, tenant_id=TENANT, limit=32
                        ),
                    )
                    write_json(
                        output / "events.json",
                        state.history_store.list_events(
                            investigation_id, tenant_id=TENANT, limit=2000
                        ),
                    )
                write_json(
                    output / "history_stats.json",
                    state.history_store.stats(tenant_id=TENANT),
                )
            finally:
                await state.dependencies.close_resources()
        index["runtime_terminal"] = terminal_state(state)
        write_json(output / "model_after.json", check_model(client, manifest))
        index["measurement_completed"] = True
        index["elapsed_ms"] = round((time.monotonic() - started) * 1000)
        index["finished_at"] = datetime.now(UTC).isoformat()
        return index


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest", type=Path, default=Path(__file__).parent / "source_manifest.json"
    )
    args = parser.parse_args()
    output: Path | None = None
    try:
        manifest, ownership, case, metric_path, manifest_body, ownership_body = (
            validate_inputs(args.manifest)
        )
        output = Path(__file__).parent / "captures" / case["case_id"]
        output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        output.mkdir(mode=0o700)
        write_bytes(output / "execution_manifest.json", manifest_body)
        write_bytes(output / "ownership.json", ownership_body)
        admission_path = metric_path.parent / (case["case_id"] + ".admission.json")
        admission_body = admission_path.read_bytes()
        assert (
            hashlib.sha256(admission_body).hexdigest()
            == case["admitted_replay"]["admission_freeze_sha256"]
        )
        write_bytes(output / "admission_freeze.json", admission_body)
        result = asyncio.run(capture(manifest, ownership, case, metric_path, output))
        write_json(output / "capture_index.json", result)
        print(
            json.dumps(
                {
                    key: result[key]
                    for key in (
                        "case_id",
                        "capture_available",
                        "pipeline_status",
                        "measurement_completed",
                    )
                }
            ),
            flush=True,
        )
        return 0
    except BaseException as error:
        diagnostic = safe_failure_diagnostics(
            error, reason_code="baseline_capture_aborted"
        )
        if output is not None and output.exists():
            write_json(output / "capture_aborted.json", diagnostic)
        print(json.dumps(diagnostic), file=sys.stderr, flush=True)
        return 130 if isinstance(error, KeyboardInterrupt) else 1


if __name__ == "__main__":
    raise SystemExit(main())
