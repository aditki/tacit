"""Bind actual scenario captures to the unchanged paired offline protocol.

Missing bundles retain failed coverage. Their schema-required empty label object
and all-zero digest are explicit unmeasured sentinels, never an attested bundle
or successful abstention. Authoritative labels.json keeps labels=None for them.
"""

import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
from tests.eval import evidence_decisions as d

ROOT = Path(__file__).resolve().parent


def save(path, value):
    with path.open("xb") as output:
        output.write(d.canonical(value))
    path.chmod(0o600)


def main():
    labels = json.loads((ROOT / "labels.json").read_bytes())
    index = json.loads((ROOT / "capture_index.json").read_bytes())
    assert labels["capture_index_sha256"] == d.sha((ROOT / "capture_index.json").read_bytes())
    model = {
        "arm": "tev", "request_model": "tev1:4b", "returned_model": "tev1:4b",
        "artifact_sha256": "4d24c6f6d61a48d9b72902f4805c5f1da53010736b834b0372377fb4bb7e53d3",
        "server_version": "0.40.15",
    }
    models = [
        {"arm": "jev", "request_model": "not-collected-jev-v1", "returned_model": "not-collected-jev-v1",
         "artifact_sha256": None, "server_version": None}, model,
    ]
    by_id = {record["case_id"]: record for record in labels["cases"]}
    cases = []
    for record in index["cases"]:
        cid = record["case_id"]
        label = by_id[cid]["labels"]
        capture = None
        if record["capture_available"]:
            capture = json.loads((ROOT / "captures" / cid / "snapshot.json").read_bytes())
            assert label is not None
        else:
            assert label is None
        case = {
            "case_id": cid, "incident_id": record["incident_id"], "family_id": record["family_id"],
            "tenant_id": "scenario-tev-evaluation", "investigation_id": record["investigation_id"],
            "revision": record.get("revision", 0),
            "bundle_path": f"../captures/{cid}/assessment.tar.gz",
            "bundle_sha256": record.get("bundle_sha256", "0" * 64),
            "stratum": "post_acquisition", "approval_ref": "frozen-scenario-labels-and-local-user-authorization-20261118",
            "redactions": {}, "labels": label or {"acceptable": [], "contradicted": [], "required_abstention": True},
            "attempts": 1,
            "request_hashes": {arm + "." + variant: None for arm in d.ARMS for variant in d.VARIANTS},
        }
        if capture is not None:
            projection, packets = d.prepare_case(case, capture, models)
            assert projection["status"] == "deterministic" and projection["reason"] == "one_candidate"
            assert not packets
        cases.append(case)
    manifest = {
        "schema_version": "evidence-decisions-manifest/1", "experiment_id": "scenario_tev_corpus_v1",
        "split": "development", "protocol": {**d.PROTOCOL, "wire": d.OLLAMA_04015_WIRE},
        "models": models, "cases": sorted(cases, key=lambda item: item["incident_id"]),
    }
    manifest["corpus_sha256"] = d.corpus_digest(manifest)
    destination = ROOT / "experiment"
    destination.mkdir(mode=0o700)
    save(destination / "manifest.json", manifest)
    assert d.load_manifest(destination / "manifest.json") == manifest
    (ROOT / "responses").mkdir(mode=0o700)
    save(ROOT / "responses/collection.json", {"schema_version": "collection/1", "approval_ref": "user-local-scenario-evaluation-20261118"})
    save(ROOT / "collection.json", {
        "schema_version": "scenario-paired-collection/1", "started_at": datetime.now(UTC).isoformat(),
        "labels_sha256": d.sha((ROOT / "labels.json").read_bytes()),
        "experiment_manifest_sha256": d.sha((destination / "manifest.json").read_bytes()),
        "request_count": 0, "tev_calls": 0, "jev_calls": 0,
        "deterministic_no_call": 9, "failed_before_capture": 4,
        "note": "No eligible ranking choices. Any supplemental shadow calls have a separate protocol and ledger.",
    })
    print(json.dumps({"cases": len(cases), "corpus_sha256": manifest["corpus_sha256"], "requests": 0}))


if __name__ == "__main__":
    main()
