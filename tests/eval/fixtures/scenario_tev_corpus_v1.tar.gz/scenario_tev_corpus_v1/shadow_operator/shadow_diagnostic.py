"""File-only, separate single-candidate abstention diagnostic; never collects."""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
from tests.eval import evidence_decisions as d

SCHEMA = "scenario-abstention-diagnostic/1"
RESULTS = "scenario-abstention-diagnostic-results/1"
TASK = "single-candidate-evidence-sufficiency/1"
IDENTIFIER = "scenario_single_candidate_20261118"
INSTRUCTIONS = d.PRIMARY + (
    " A validated, non-empty query records availability; it does not by itself establish a measured abnormal condition."
)


def read_json(path: Path, limit=10 * 1024 * 1024):
    body = d.read_file(path, limit)
    return d.decode_json(body), d.sha(body)


def check_expected_label(labels):
    d.require(
        isinstance(labels, dict)
        and labels.get("acceptable") == []
        and labels.get("required_abstention") is True
    )


def make_packet(capture, model, approvals):
    p = d.captured_projection(capture)
    d.require(p["status"] == "deterministic" and len(p["menu"]) == 1)
    d.validate_wire_identity(model, d.OLLAMA_04015_WIRE)
    state = d.apply_approvals(p["state"], approvals)
    cid = p["menu"][0]
    visible = {
        **state,
        "candidates": [{"candidate_id": cid, **state["candidates"][cid]}],
    }
    packet = {
        "model": model["request_model"],
        "state": visible,
        "questions": {
            "priority": {
                "type": "choice",
                "instructions": INSTRUCTIONS,
                "criteria": {
                    cid: "Consider this captured suspect next",
                    "insufficient": "The recorded facts do not justify prioritizing a suspect",
                },
            }
        },
    }
    d.require(len(d.wire_bytes(packet)) <= d.PACKET_LIMIT, "input_limit")
    return packet, p


def manifest_digest(m):
    value = copy.deepcopy(m)
    value.pop("diagnostic_digest", None)
    for case in value["cases"]:
        case.pop("bundle_path", None)
    return d.sha(d.canonical(value))


def rederive(case, model, manifest_path):
    capture = d.load_bundle(
        manifest_path.parent / case["bundle_path"], case, {"bundles": 0, "expanded": 0}
    )
    packet, p = make_packet(capture, model, case["approved_text"])
    d.require(p["menu"] == [case["candidate_id"]])
    body = d.wire_bytes(packet)
    d.require(
        d.sha(body) == case["request_sha256"]
        and d.sha(d.canonical(packet["state"])) == case["state_sha256"]
    )
    d.require(case["expected_choice"] == "insufficient")
    return body


def load_manifest(path):
    m, _ = read_json(path)
    d.closed(
        m,
        "schema_version task diagnostic_id protocol_sha256 source_manifest_sha256 labels_sha256 label_adjudication_sha256 capture_index_sha256 model wire_profile approval_ref cases diagnostic_digest",
    )
    d.require(
        m["schema_version"] == SCHEMA
        and m["task"] == TASK
        and m["diagnostic_id"] == IDENTIFIER
    )
    d.require(m["wire_profile"] == d.OLLAMA_04015_WIRE and len(m["cases"]) == 9)
    d.validate_wire_identity(m["model"], m["wire_profile"])
    d.require(m["model"]["arm"] == "tev")
    d.require(len({case["case_id"] for case in m["cases"]}) == 9)
    d.require(manifest_digest(m) == m["diagnostic_digest"])
    return m


def prepare(root, identity_path, protocol_path, approval_ref, output):
    labels, labels_sha = read_json(root / "labels.json")
    master, master_sha = read_json(root / "source_manifest.json")
    _, freeze_sha = read_json(root / "source_freeze.json")
    _, index_sha = read_json(root / "capture_index.json")
    _, adjudication_sha = read_json(root / "label_adjudication.json")
    protocol, protocol_sha = read_json(protocol_path)
    d.require(protocol["schema_version"] == "scenario-abstention-diagnostic-protocol/1")
    d.require(protocol["task"] == TASK and protocol["instructions"] == INSTRUCTIONS)
    d.require(
        protocol["max_inference_calls"] == 9 and protocol["automatic_retries"] == 0
    )
    d.require(
        labels["schema_version"] == "scenario-labels/1" and bool(labels["frozen_at"])
    )
    d.require(
        labels["source_manifest_sha256"] == master_sha
        and labels["source_freeze_sha256"] == freeze_sha
    )
    d.require(
        labels["capture_index_sha256"] == index_sha
        and labels["label_adjudication_sha256"] == adjudication_sha
    )
    identity, _ = read_json(identity_path)
    model = {
        "arm": "tev",
        "request_model": identity["requested_model"],
        **{
            key: identity[key]
            for key in ("returned_model", "artifact_sha256", "server_version")
        },
    }
    d.require(model["request_model"] == model["returned_model"] == "tev1:4b")
    d.digest(model["artifact_sha256"])
    d.validate_wire_identity(model, d.OLLAMA_04015_WIRE)
    source_by_id = {item["case_id"]: item for item in master["cases"]}
    cases, packets = [], {}
    for label in labels["cases"]:
        cid = label["case_id"]
        index_path = root / "captures" / cid / "capture_index.json"
        index, per_index_sha = read_json(index_path)
        if not index["capture_available"]:
            d.require(label["labels"] is None)
            continue
        check_expected_label(label["labels"])
        source = source_by_id[cid]
        bundle = root / "captures" / cid / "assessment.tar.gz"
        case = {
            "case_id": cid,
            "incident_id": source["incident_id"],
            "family_id": source["family_id"],
            "tenant_id": "scenario-tev-evaluation",
            "investigation_id": index["investigation_id"],
            "revision": index["revision"],
            "capture_index_sha256": per_index_sha,
            "bundle_path": os.path.relpath(bundle, output),
            "bundle_sha256": index["bundle_sha256"],
            "expected_choice": "insufficient",
        }
        capture = d.load_bundle(bundle, case, {"bundles": 0, "expanded": 0})
        projection = d.captured_projection(capture)
        d.require(
            projection["status"] == "deterministic" and len(projection["menu"]) == 1
        )
        approvals = {
            key: {"source_sha256": d.sha(value.encode()), "replacement": value}
            for key, value in d.approval_leaves(projection["state"]).items()
        }
        packet, p = make_packet(capture, model, approvals)
        body = d.wire_bytes(packet)
        case.update(
            candidate_id=p["menu"][0],
            approved_text=approvals,
            state_sha256=d.sha(d.canonical(packet["state"])),
            request_sha256=d.sha(body),
        )
        cases.append(case)
        packets[cid] = body
    d.require(len(cases) == 9)
    m = {
        "schema_version": SCHEMA,
        "task": TASK,
        "diagnostic_id": IDENTIFIER,
        "protocol_sha256": protocol_sha,
        "source_manifest_sha256": master_sha,
        "labels_sha256": labels_sha,
        "label_adjudication_sha256": adjudication_sha,
        "capture_index_sha256": index_sha,
        "model": model,
        "wire_profile": d.OLLAMA_04015_WIRE,
        "approval_ref": d.text(approval_ref, nonempty=True),
        "cases": sorted(cases, key=lambda item: item["case_id"]),
    }
    m["diagnostic_digest"] = manifest_digest(m)
    with_output = d.Output(output, "prepare")
    try:
        os.mkdir("requests", mode=0o700, dir_fd=with_output.fd)
        for cid, body in sorted(packets.items()):
            with_output.write("requests/" + cid + ".json", body)
        with_output.write("manifest.json", d.canonical(m))
        with_output.complete()
    finally:
        with_output.close()
    return m


def score(manifest_path, responses, output):
    m = load_manifest(manifest_path)
    expected = {case["case_id"] + ".tev.primary.a1.json" for case in m["cases"]}
    d.check_response_directory(responses, expected)
    rows, groups = [], {}
    for case in m["cases"]:
        rederive(case, m["model"], manifest_path)
        row = {
            "case_id": case["case_id"],
            "family_id": case["family_id"],
            "state_sha256": case["state_sha256"],
            "request_sha256": case["request_sha256"],
            "receipt_sha256": None,
            "valid": False,
            "choice": None,
            "label_error": None,
            "reason": "missing_receipt",
            "usage": None,
            "elapsed_ms": None,
        }
        try:
            body = d.read_file(
                responses / (case["case_id"] + ".tev.primary.a1.json"), d.RESPONSE_LIMIT
            )
            row["receipt_sha256"] = d.sha(body)
            receipt = d.decode_json(body)
            d.require(
                receipt["experiment_id"] == IDENTIFIER
                and receipt["case_id"] == case["case_id"]
            )
            d.require(receipt["variant"] == "primary" and receipt["attempt"] == 1)
            result = d.validate_receipt(
                receipt,
                m["model"],
                {case["candidate_id"], "insufficient"},
                case["request_sha256"],
                wire_profile=m["wire_profile"],
            )
            row.update(
                {
                    key: result[key]
                    for key in ("valid", "choice", "reason", "usage", "elapsed_ms")
                }
            )
            row["label_error"] = (
                result["choice"] != "insufficient" if result["valid"] else None
            )
        except FileNotFoundError:
            pass
        except (OSError, ValueError, KeyError, TypeError):
            row["reason"] = "invalid_response"
        rows.append(row)
        group = groups.setdefault(
            case["request_sha256"],
            {"state_sha256": case["state_sha256"], "case_ids": [], "valid_choices": []},
        )
        group["case_ids"].append(case["case_id"])
        if row["valid"]:
            group["valid_choices"].append(row["choice"])
    report = {
        "schema_version": RESULTS,
        "task": TASK,
        "diagnostic_digest": m["diagnostic_digest"],
        "counts": {
            "case_calls": len(rows),
            "valid": sum(row["valid"] for row in rows),
            "label_errors": sum(row["label_error"] is True for row in rows),
            "insufficient_choices": sum(
                row["valid"] and row["choice"] == "insufficient" for row in rows
            ),
            "unique_inputs": len(groups),
        },
        "groups": [
            {"request_sha256": key, **value} for key, value in sorted(groups.items())
        ],
        "rows": rows,
        "paired_priority_evaluation": False,
        "positive_class_coverage": 0,
        "adoption_gate": "not_applicable_diagnostic_only",
    }
    report["semantic_sha256"] = d.sha(d.canonical(report))
    out = d.Output(output, "score")
    try:
        out.write("report.json", d.canonical(report))
        out.complete()
    finally:
        out.close()
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    prep = commands.add_parser("prepare")
    for name in ("root", "identity", "protocol", "out"):
        prep.add_argument("--" + name, required=True, type=Path)
    prep.add_argument("--approval-ref", required=True)
    scoring = commands.add_parser("score")
    for name in ("manifest", "responses", "out"):
        scoring.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    if args.command == "prepare":
        result = prepare(
            args.root, args.identity, args.protocol, args.approval_ref, args.out
        )
        print(
            json.dumps(
                {
                    "diagnostic_digest": result["diagnostic_digest"],
                    "case_requests": len(result["cases"]),
                }
            )
        )
        return 0
    report = score(args.manifest, args.responses, args.out)
    print(
        json.dumps(
            {"counts": report["counts"], "semantic_sha256": report["semantic_sha256"]}
        )
    )
    return int(report["counts"]["valid"] != report["counts"]["case_calls"])


if __name__ == "__main__":
    raise SystemExit(main())
