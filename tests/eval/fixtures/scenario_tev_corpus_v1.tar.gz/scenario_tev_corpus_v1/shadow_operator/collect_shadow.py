"""External operator collection; serial loopback requests, never imported by scorer."""

import argparse
import json
import os
import time
import urllib.error
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

import shadow_diagnostic as s


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise RuntimeError("redirect forbidden")


def write(path, body):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(body)


def verify_frozen_inputs(manifest_path, manifest):
    root = manifest_path.parent.parent.parent
    checks = {
        root / "source_manifest.json": "source_manifest_sha256",
        root / "labels.json": "labels_sha256",
        root / "capture_index.json": "capture_index_sha256",
        root / "label_adjudication.json": "label_adjudication_sha256",
        manifest_path.parent.parent / "protocol.json": "protocol_sha256",
    }
    for path, field in checks.items():
        s.d.require(
            s.d.sha(s.d.read_file(path, 10 * 1024 * 1024)) == manifest[field],
            "frozen_input_changed",
        )
    s.d.require(s.load_manifest(manifest_path) == manifest, "frozen_manifest_changed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--api-base",
        choices=["http://127.0.0.1:11434"],
        default="http://127.0.0.1:11434",
    )
    args = parser.parse_args()
    manifest = s.load_manifest(args.manifest)
    verify_frozen_inputs(args.manifest, manifest)
    model = manifest["model"]
    requests = [
        (case, s.rederive(case, model, args.manifest)) for case in manifest["cases"]
    ]
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

    def get(path):
        with opener.open(args.api_base + path, timeout=10) as response:
            body = response.read(1024 * 1024 + 1)
        s.d.require(len(body) <= 1024 * 1024, "input_limit")
        return s.d.decode_json(body)

    def identity():
        s.d.require(get("/api/version")["version"] == model["server_version"])
        selected = next(
            item
            for item in get("/api/tags")["models"]
            if item["name"] == model["request_model"]
        )
        s.d.require(selected["digest"] == model["artifact_sha256"])
        # The entire model inventory is never written to output.

    args.out.mkdir(mode=0o700, exist_ok=True)
    s.d.require(not args.out.is_symlink() and args.out.is_dir())
    responses = args.out / "responses"
    responses.mkdir(mode=0o700)
    raw_dir = args.out / "raw"
    raw_dir.mkdir(mode=0o700)
    write(
        args.out / "collection_start.json",
        s.d.canonical(
            {
                "schema_version": "scenario-abstention-diagnostic-collection-start/1",
                "started_at": datetime.now(UTC).isoformat(),
                "manifest_sha256": s.d.sha(
                    s.d.read_file(args.manifest, 10 * 1024 * 1024)
                ),
                "diagnostic_digest": manifest["diagnostic_digest"],
                "model": model,
                "max_inference_calls": 9,
                **{
                    key: manifest[key]
                    for key in (
                        "labels_sha256",
                        "protocol_sha256",
                        "capture_index_sha256",
                        "source_manifest_sha256",
                        "label_adjudication_sha256",
                    )
                },
                "timing_semantics": "600-second new-call admission budget; 60-second socket-operation timeout; no worker retirement inference",
            }
        ),
    )
    deadline = time.monotonic() + 600
    ledger = []
    for case, body in requests:
        s.d.require(time.monotonic() < deadline, "external_timeout")
        identity()
        s.d.require(len(ledger) < 9 and len(body) <= s.d.PACKET_LIMIT)
        remaining = deadline - time.monotonic()
        s.d.require(remaining > 0, "external_timeout")
        request = urllib.request.Request(
            args.api_base + "/v1/systemone",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        started = time.monotonic()
        try:
            try:
                response = opener.open(request, timeout=min(60, remaining))
            except urllib.error.HTTPError as error:
                response = error
            with response:
                status = response.status
                raw_body = response.read(s.d.RESPONSE_LIMIT + 1)
            s.d.require(len(raw_body) <= s.d.RESPONSE_LIMIT, "input_limit")
        except (TimeoutError, OSError, KeyboardInterrupt) as error:
            write(
                args.out / "uncertain_stop.json",
                s.d.canonical(
                    {
                        "case_id": case["case_id"],
                        "reason": "transport_loss_remote_settlement_unknown",
                        "error_type": type(error).__name__,
                        "confirmed_receipts": len(ledger),
                        "automatic_retries": 0,
                    }
                ),
            )
            # Closing transport does not attest worker retirement. Stop serial
            # admission; do not retry, unload a model, or invent a receipt.
            return 1
        elapsed = round((time.monotonic() - started) * 1000)
        name = case["case_id"] + ".tev.primary.a1.json"
        write(raw_dir / name, raw_body)
        raw = s.d.decode_json(raw_body)
        receipt = {
            "schema_version": "evidence-decisions-receipt/1",
            "experiment_id": s.IDENTIFIER,
            "case_id": case["case_id"],
            "arm": "tev",
            "variant": "primary",
            "attempt": 1,
            "request_sha256": case["request_sha256"],
            "identity": {
                key: model[key]
                for key in ("returned_model", "artifact_sha256", "server_version")
            },
            "status": "ok" if status == 200 else "error",
            "raw": raw if status == 200 else None,
            "usage": raw.get("usage") if status == 200 else None,
            "elapsed_ms": elapsed,
            "error_code": None if status == 200 else "external_failure",
        }
        recorded = s.d.canonical(receipt)
        write(responses / name, recorded)
        ledger.append(
            {
                "case_id": case["case_id"],
                "request_sha256": case["request_sha256"],
                "raw_response_sha256": s.d.sha(raw_body),
                "receipt_sha256": s.d.sha(recorded),
                "http_status": status,
                "elapsed_ms": elapsed,
            }
        )
        print(json.dumps({"recorded": len(ledger)}), flush=True)
    identity()
    verify_frozen_inputs(args.manifest, manifest)
    write(
        args.out / "collection.json",
        s.d.canonical(
            {
                "schema_version": "scenario-abstention-diagnostic-collection/1",
                "diagnostic_digest": manifest["diagnostic_digest"],
                "actual_inference_calls": len(ledger),
                "finished_at": datetime.now(UTC).isoformat(),
                "automatic_retries": 0,
                "model": model,
                "receipts": ledger,
                "worker_owner": "existing Ollama server",
                "caller_cleanup_authority": "operator HTTP transports only",
                "timeout_policy": "stop admission on transport loss; remote retirement is not inferred",
            }
        ),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
