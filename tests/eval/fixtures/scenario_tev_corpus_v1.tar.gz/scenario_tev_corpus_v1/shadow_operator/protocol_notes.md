# Separate abstention diagnostic operator notes

This task does not alter the paired `priority-v1` no-call policy. Nine captured
case calls represent only two unique model-visible states. All nine frozen labels
are insufficient; there is no positive-class or general ranking-quality estimate.
Choosing the candidate is a label error under this probe, not a causal assertion.

The frozen protocol's 600-second value is a **new-call admission budget**.
urllib's 60-second timeout applies to socket operations, not strict wall-clock
model retirement. The existing Ollama server is the model-worker capacity and
cleanup owner. On cancellation or transport loss the operator records uncertain
remote settlement and stops without retrying, admitting another call or unloading
shared models. It has no thread, event loop, runtime capacity or fallback owner.

`collection_start.json` binds the final manifest, protocol, labels and source/index
hashes before the first call. Those files are rechecked after the last response.
Exact raw responses and receipts remain distinct; metadata does not silently
become a successful prediction. Offline scoring makes no external calls.
