"""Pure pre-inference boundary tests for the separate abstention diagnostic."""

import copy
import importlib.util
import json
import socket
import sqlite3
import subprocess
import unittest
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "shadow", Path(__file__).with_name("shadow_diagnostic.py")
)
shadow = importlib.util.module_from_spec(spec)
spec.loader.exec_module(shadow)


def fixture():
    value = json.loads(
        (Path.cwd() / "tests/eval/fixtures/evidence_decisions_v1.json").read_text()
    )
    capture = copy.deepcopy(value["synthetic_capture"])
    capture["culprit_ranking"]["candidates"] = capture["culprit_ranking"]["candidates"][
        :1
    ]
    state = shadow.d.captured_projection(capture)["state"]
    approvals = {
        key: {"source_sha256": shadow.d.sha(text.encode()), "replacement": text}
        for key, text in shadow.d.approval_leaves(state).items()
    }
    model = {
        "arm": "tev",
        "request_model": "tev1:4b",
        "returned_model": "tev1:4b",
        "artifact_sha256": "1" * 64,
        "server_version": "0.40.15",
    }
    return capture, approvals, model


class ShadowTests(unittest.TestCase):
    def test_uses_one_real_candidate_plus_insufficient_without_mutating_policy(self):
        capture, approvals, model = fixture()
        before = copy.deepcopy(capture)
        packet, projection = shadow.make_packet(capture, model, approvals)
        self.assertEqual(projection["status"], "deterministic")
        self.assertEqual(capture, before)
        self.assertEqual(
            set(packet["questions"]["priority"]["criteria"]),
            {projection["menu"][0], "insufficient"},
        )
        self.assertEqual(len(packet["state"]["candidates"]), 1)
        self.assertFalse(
            {"rank", "score", "confidence", "labels"}
            & packet["state"]["candidates"][0].keys()
        )

    def test_missing_text_approval_rejects(self):
        capture, approvals, model = fixture()
        approvals.pop(next(iter(approvals)))
        with self.assertRaises(shadow.d.ValidationError):
            shadow.make_packet(capture, model, approvals)

    def test_captured_abstention_cannot_be_probed(self):
        capture, approvals, model = fixture()
        capture["culprit_ranking"]["abstained"] = True
        with self.assertRaises(shadow.d.ValidationError):
            shadow.make_packet(capture, model, approvals)

    def test_two_supported_candidates_cannot_enter_this_diagnostic(self):
        capture, approvals, model = fixture()
        candidate = copy.deepcopy(capture["culprit_ranking"]["candidates"][0])
        candidate["suspect"] = "second"
        capture["culprit_ranking"]["candidates"].append(candidate)
        with self.assertRaises(shadow.d.ValidationError):
            shadow.make_packet(capture, model, approvals)

    def test_frozen_expected_label_is_insufficient(self):
        with self.assertRaises(shadow.d.ValidationError):
            shadow.check_expected_label(
                {"acceptable": ["candidate_" + "1" * 64], "required_abstention": False}
            )

    def test_import_and_packet_need_no_external_capabilities(self):
        capture, approvals, model = fixture()
        with patch.object(
            socket, "socket", side_effect=AssertionError("socket")
        ), patch.object(
            sqlite3, "connect", side_effect=AssertionError("database")
        ), patch.object(
            subprocess, "Popen", side_effect=AssertionError("process")
        ):
            shadow.make_packet(capture, model, approvals)


if __name__ == "__main__":
    unittest.main()
